#include "F_Node.h"

F_Node::F_Node()
{
	Id = 0;
	ComplaintDescription = "";
	ComplaintBy = "";
	Left = nullptr;
	Right = nullptr;
	Previous = nullptr;
}
