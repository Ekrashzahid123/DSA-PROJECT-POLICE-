#include "C_Node.h"

C_Node::C_Node()
{
	Id = 0;
	Offense = "";
	Name = "";
	Left = nullptr;
	Right = nullptr;
	Previous = nullptr;
}
