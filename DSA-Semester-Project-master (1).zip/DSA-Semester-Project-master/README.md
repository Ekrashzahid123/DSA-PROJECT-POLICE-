Note: This is my 3rd semester final project so it's gonna have a lot of errors and bad code which will improve as the deadline for the project approaches :)
