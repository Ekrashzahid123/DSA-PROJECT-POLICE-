#pragma once
/* This section contains all the abbreviations and comments / explanation for different parts of the code
	P_List stands for "Police officers list"
	P_Node stands for "Police officers node"
*/