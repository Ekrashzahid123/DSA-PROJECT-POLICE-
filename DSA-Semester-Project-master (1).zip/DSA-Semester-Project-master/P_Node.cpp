#include "P_Node.h"

P_Node::P_Node()
{
	Id = 0;
	Rank = 0;
	Name = "";
	Left = nullptr;
	Right = nullptr;
	Previous = nullptr;
}
