#pragma once
class C_Node
{
};

